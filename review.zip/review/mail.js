const firebaseConfig = {
  apiKey: "AIzaSyAC5gSRVqp3fQwsBZ4xfqacuj3un-ZWAtQ",
    authDomain: "rateandreview-81f8a.firebaseapp.com",
    databaseURL: "https://rateandreview-81f8a-default-rtdb.firebaseio.com",
    projectId: "rateandreview-81f8a",
    storageBucket: "rateandreview-81f8a.appspot.com",
    messagingSenderId: "838700988928",
    appId: "1:838700988928:web:9418360aff849e9e0936e5"

};

// initialize firebase
firebase.initializeApp(firebaseConfig);

// reference your database
var contactFormDB = firebase.database().ref("contactForm");

document.getElementById("contactForm").addEventListener("submit", submitForm);

function submitForm(e) {
  e.preventDefault();

  var name = getElementVal("name");
  var emailid = getElementVal("emailid");
  var msgContent = getElementVal("msgContent");

  saveMessages(name, emailid, msgContent);

  //   enable alert
  document.querySelector(".alert").style.display = "block";

  //   remove the alert
  setTimeout(() => {
    document.querySelector(".alert").style.display = "none";
  }, 3000);

  //   reset the form
  document.getElementById("contactForm").reset();
}

const saveMessages = (name, emailid, msgContent) => {
  var newContactForm = contactFormDB.push();

  newContactForm.set({
    name: name,
    emailid: emailid,
    msgContent: msgContent,
  });
};

const getElementVal = (id) => {
  return document.getElementById(id).value;
};